package com.simpli.hibernate.entity;
import java.util.List;
public class Patients {
	private int Id;
    private String Name;
    private int Age;
    private String Email;
    private int Phone;
    private String Diagnosis;
    private String Remark;
    private String Gender;
    
    public int getId() {
        return Id;
    }
    public void setId(int Id) {
        this.Id = Id;
    }
    public String getName() {
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }
    public int getAge() {
        return Age;
    }
    public void setAge(int Age) {
        this.Age = Age;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String Email) {
        this.Email = Email;
    }
    public int getPhone() {
        return Phone;
    }
    public void setPhone(int Phone) {
        this.Phone = Phone;
    }
    public String getDiagnosis() {
        return Diagnosis;
    }
    public void setDiagnosis(String Diagnosis) {
        this.Diagnosis = Diagnosis;
    }
    public String getRemark() {
        return Remark;
    }
    public void setRemark(String Remark) {
        this.Remark = Remark;
    }
    public String getGender() {
        return Gender;
    }
    public void setGender(String Gender) {
        this.Gender = Gender;
    }
	public static List<Patients> list() {
		// TODO Auto-generated method stub
		return null;
	}    


}

package com.simpli.hibernate.entity;
import java.util.List;

public class vital {
	private int V_id;
    private String Name;    
    private int Phone;
    private int BP_Low;
    private int BP_High;
    private int SPO2;
    private String Recorded_On;
    
    public int getV_id() {
        return V_id;
    }
    public void setV_id(int V_id) {
        this.V_id = V_id;
    }
    public String getName() {
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }       
    public int getPhone() {
        return Phone;
    }
    public void setPhone(int Phone) {
        this.Phone = Phone;
    }    
	public int getBP_Low() {
		return BP_Low;
	}
	public void setBP_Low(int BP_Low) {
		this.BP_Low = BP_Low;
	}
	public int getBP_High() {
		return BP_High;
	}
	public void setBP_High(int BP_High) {
		this.BP_High = BP_High;
	}
	public int getSPO2() {
		return SPO2;
	}
	public void setSPO2(int SPO2) {
		this.SPO2 = SPO2;
	}
	public String getRecorded_On() {
		return Recorded_On;
	}
	public void setRecorded_On(String Recorded_On) {
		this.Recorded_On = Recorded_On;
	}
	public static List<vital> list() {
		// TODO Auto-generated method stub
		return null;
	}    



}

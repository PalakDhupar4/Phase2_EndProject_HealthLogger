package com.simpli.hibernate.servlets;
 
import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


import com.simpli.hibernate.entity.vital;
import com.simpli.hibernate.util.HibernateUtils;

import jakarta.persistence.Query;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
public class GetDataServlet2 extends HttpServlet {
   private static final long serialVersionUID = 1L;
 
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
      SessionFactory factory = HibernateUtils.getSessionFactory();
      Session session = factory.openSession();
 
      Query query = session.createQuery("from vital");
 
      List<vital> vital = session.createQuery("from vital").list();
   
      session.close();
      request.setAttribute("vital", vital);
 
      request.getRequestDispatcher("vitalDetails.jsp").forward(request, response);        
    }
}
package com.simpli.hibernate.servlets;
 
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.simpli.hibernate.entity.Patients;
import com.simpli.hibernate.util.HibernateUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 

public class InsertPatientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
        String Name = request.getParameter("Name");
        String Age = request.getParameter("Age");
        String Email = request.getParameter("Email");
        String Phone = request.getParameter("Phone");
        String Diagnosis = request.getParameter("Diagnosis");
        String Remark = request.getParameter("Remark");
        String Gender = request.getParameter("Gender");
 
        Patients patients = new Patients();
        patients.setName(Name);
        patients.setAge(Integer.parseInt(Age));
        patients.setEmail(Email);
        patients.setPhone(Integer.parseInt(Phone));
        patients.setDiagnosis(Diagnosis);
        patients.setRemark(Remark);
        patients.setGender(Gender);
 
        SessionFactory factory = HibernateUtils.getSessionFactory();
        Session session = factory.openSession();
 
        Transaction tx = session.beginTransaction();
        session.save(patients);
 
        session.flush();
        tx.commit();
        session.close();
        response.sendRedirect("GetDataServlet");
    }
}

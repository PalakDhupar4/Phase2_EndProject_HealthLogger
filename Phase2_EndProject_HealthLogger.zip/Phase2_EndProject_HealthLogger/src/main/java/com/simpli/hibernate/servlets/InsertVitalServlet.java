package com.simpli.hibernate.servlets;
 
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.simpli.hibernate.entity.vital;
import com.simpli.hibernate.util.HibernateUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 

public class InsertVitalServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
        String Name = request.getParameter("Name");
        String Phone = request.getParameter("Phone");
        String BP_Low = request.getParameter("BP_Low");
        String BP_High = request.getParameter("BP_High");
        String SPO2 = request.getParameter("SPO2");
        String Recorded_On = request.getParameter("Recorded_On");
 
        vital vital = new vital();
        vital.setName(Name);
        vital.setPhone(Integer.parseInt(Phone));
        vital.setBP_Low(Integer.parseInt(BP_Low));
        vital.setBP_High(Integer.parseInt(BP_High));
        vital.setSPO2(Integer.parseInt(SPO2));
        vital.setRecorded_On(Recorded_On);
 
        SessionFactory factory = HibernateUtils.getSessionFactory();
        Session session = factory.openSession();
 
        Transaction tx = session.beginTransaction();
        session.save(vital);
 
        session.flush();
        tx.commit();
        session.close();
        response.sendRedirect("GetDataServlet2");
    }
}